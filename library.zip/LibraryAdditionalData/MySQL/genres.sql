/*
 Navicat Premium Data Transfer

 Source Server         : local_mysql
 Source Server Type    : MySQL
 Source Server Version : 80015
 Source Host           : localhost:3306
 Source Schema         : library

 Target Server Type    : MySQL
 Target Server Version : 80015
 File Encoding         : 65001

 Date: 20/12/2019 01:09:55
*/
-- ----------------------------
-- Records of genres
-- ----------------------------
INSERT INTO `library`.`genres`(`name`) VALUES ('Бизнес-книги');
INSERT INTO `library`.`genres`(`name`) VALUES ('Классическая литература');
INSERT INTO `library`.`genres`(`name`) VALUES ('Зарубежная литература');
INSERT INTO `library`.`genres`(`name`) VALUES ('Русская литература');
INSERT INTO `library`.`genres`(`name`) VALUES ('Детские книги');
INSERT INTO `library`.`genres`(`name`) VALUES ('Детективы');
INSERT INTO `library`.`genres`(`name`) VALUES ('Фэнтези');
INSERT INTO `library`.`genres`(`name`) VALUES ('Фантастика');
INSERT INTO `library`.`genres`(`name`) VALUES ('Современная проза');
INSERT INTO `library`.`genres`(`name`) VALUES ('Приключения');
INSERT INTO `library`.`genres`(`name`) VALUES ('Ужасы, мистика');
INSERT INTO `library`.`genres`(`name`) VALUES ('Публицистическая литература');
INSERT INTO `library`.`genres`(`name`) VALUES ('Книги для подростков');
INSERT INTO `library`.`genres`(`name`) VALUES ('Любовные романы');
INSERT INTO `library`.`genres`(`name`) VALUES ('Боевики, остросюжетная литература');
INSERT INTO `library`.`genres`(`name`) VALUES ('Книги по психологии');
INSERT INTO `library`.`genres`(`name`) VALUES ('Повести, рассказы');
INSERT INTO `library`.`genres`(`name`) VALUES ('Поэзия и драматургия');
INSERT INTO `library`.`genres`(`name`) VALUES ('Наука и образование');
INSERT INTO `library`.`genres`(`name`) VALUES ('Дом, семья, хобби и досуг');
INSERT INTO `library`.`genres`(`name`) VALUES ('Комиксы, манга');
INSERT INTO `library`.`genres`(`name`) VALUES ('Эзотерика');
INSERT INTO `library`.`genres`(`name`) VALUES ('Культура и искусство');
INSERT INTO `library`.`genres`(`name`) VALUES ('Юмористическая литература');
INSERT INTO `library`.`genres`(`name`) VALUES ('Религия');
INSERT INTO `library`.`genres`(`name`) VALUES ('Словари, справочники');
INSERT INTO `library`.`genres`(`name`) VALUES ('Красота и здоровье');
INSERT INTO `library`.`genres`(`name`) VALUES ('Компьютерная литература');
INSERT INTO `library`.`genres`(`name`) VALUES ('Эротика и секс');
INSERT INTO `library`.`genres`(`name`) VALUES ('Периодические издания');
INSERT INTO `library`.`genres`(`name`) VALUES ('Учебная литература');
INSERT INTO `library`.`genres`(`name`) VALUES ('Исторический роман');
INSERT INTO `library`.`genres`(`name`) VALUES ('Магический реализм');
INSERT INTO `library`.`genres`(`name`) VALUES ('ЛГБТ');
