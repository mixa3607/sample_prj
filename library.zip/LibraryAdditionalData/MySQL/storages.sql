/*
 Navicat Premium Data Transfer

 Source Server         : local_mysql
 Source Server Type    : MySQL
 Source Server Version : 80015
 Source Host           : localhost:3306
 Source Schema         : library

 Target Server Type    : MySQL
 Target Server Version : 80015
 File Encoding         : 65001

 Date: 20/12/2019 01:12:25
*/
-- ----------------------------
-- Records of storages
-- ----------------------------
INSERT INTO `storages` VALUES (1, '/static/images/');

