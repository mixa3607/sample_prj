<?php


namespace ClassDef;


class Book
{
    public $id;
    public $title;
    public $image;
    public $authors;
    public $genres;
    public $pubDate;
}