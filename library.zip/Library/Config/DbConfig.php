<?php


namespace Config;


class DbConfig
{
    public const HOST = "127.0.0.1"; //"nbc.local.arkprojects.space"; //resolve to nb in lan (192.168.1.51)
    public const PORT = 3306;
    public const LOGIN = "admin";
    public const PASSWORD = "admin";
    public const DB_NAME = "library";
}